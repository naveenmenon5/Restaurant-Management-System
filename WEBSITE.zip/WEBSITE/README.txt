
TITLE: 
RESTAURANT MANAGEMENT SYSTEM

AUTHOR:
DESIGNED & DEVELOPED by B1 GROUP OF THIRD YEAR BTECH COMPUTER STUDENTS

NAVEEN MENON: TCOA29
RUSHIKESH MORE: TCOA31
GANESH PAVNE: TCOA36

*IMPORTANT*
DO NOT DUPLICATE THIS PROJECT CODE
THIS IS ONLY FOR REFERENCE and EDUCATIONAL PURPOSES
EXTRACT THE ABOVE FOLDERS IMAGES AND CODE TO YOUR OWN PC
GIVE IT PROPER NAME AND REFERENCE
ACCESS DATABASE VIA PHPMYADMIN
OPEN page.html for final presentation

CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Themify Icons
https://themify.me/themify-icons

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Owl Carousel
http://www.owlcarousel.owlgraphic.com/

jQuery countTo
http://www.owlcarousel.owlgraphic.com/

Magnific Popup
http://dimsemenov.com/plugins/magnific-popup/

MomentJS
https://github.com/moment/moment

Bootstrap DateTimePicker
http://eonasdan.github.io/bootstrap-datetimepicker/

Stellar Parallax
http://markdalgleish.com/projects/stellar.js/

Demo Images:
http://unsplash.com

